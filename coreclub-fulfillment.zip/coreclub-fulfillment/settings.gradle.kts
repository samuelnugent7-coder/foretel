rootProject.name = "coreclub-fulfillment"
